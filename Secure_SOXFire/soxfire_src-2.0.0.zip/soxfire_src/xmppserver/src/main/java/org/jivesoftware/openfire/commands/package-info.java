/**
 * Ad-Hoc Commands implementation (XEP-0050).
 */
package org.jivesoftware.openfire.commands;
