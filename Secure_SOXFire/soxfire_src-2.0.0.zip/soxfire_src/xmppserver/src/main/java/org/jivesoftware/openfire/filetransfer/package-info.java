/**
 * Implementation of SOCKS5 Bytestreams (XEP-0065).
 */
package org.jivesoftware.openfire.filetransfer;
