/**
 * Data forms implementation (XEP-0004).
 */
package org.jivesoftware.openfire.forms;
